﻿DataForge: A -> B. Усі рядки обох джерел збережені; status=error потребує виправлення.
CSV: UTF-8-SIG, усі поля в лапках. Імпортуйте SKU як текст або використайте summary.xlsx.
Формульний текст у CSV має захисний апостроф. raw_json містить початкові значення.
Валюти не конвертуються. Правила: {"trim": false, "sku_trim": false, "sku_spaces": false, "sku_upper": false}
Порівняння ввімкнене: True
