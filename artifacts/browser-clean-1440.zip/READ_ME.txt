﻿Перевірений каталог: normalized.
DataForge: A -> B. Усі рядки обох джерел збережені; status=error потребує виправлення.
CSV: UTF-8-SIG, усі поля в лапках. Імпортуйте SKU як текст або використайте summary.xlsx.
Формульний текст у CSV має захисний апостроф. raw_json містить початкові значення.
Валюти не конвертуються. Правила: {"trim": false, "sku_trim": false, "sku_spaces": false, "sku_upper": false, "composite": false, "name_trim": false, "name_casefold": false, "require_sku": true, "require_name": true, "unique": true, "nonnegative_price": true, "nonnegative_stock": true, "integer_stock": true, "threshold": "20"}
Порівняння ввімкнене: True
